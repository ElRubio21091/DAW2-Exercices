import { DADES_PROVA } from './dades.js';

// Inputs i resultats
const inNom = <HTMLInputElement>document.getElementById("nom");
const inTelefon = <HTMLInputElement>document.getElementById("telefon");
const inEmail = <HTMLInputElement>document.getElementById("email");
const selCategoria = <HTMLSelectElement>document.getElementById("categoria");
const divResultat = <HTMLDivElement>document.getElementById("resultat");

// Botons
const btnAfegir = document.getElementById("btnAfegir")!;
const btnCercar = document.getElementById("btnCercar")!;
const btnModificar = document.getElementById("btnModificar")!;
const btnEliminar = document.getElementById("btnEliminar")!;
const btnLlistar = document.getElementById("btnLlistar")!;
const btnOrdenar = document.getElementById("btnOrdenar")!;
const btnFiltrar = document.getElementById("btnFiltrar")!;


// TODO: escriu aquí les funcions per gestionar les accions de l'usuari (clics en els botons)



// TODO: aquesta funció ha de ser anònima i autoexecutable
function carregarDadesProva(dades): void {
    // TODO: escriu aquí el codi per carregar les dades de prova
}

carregarDadesProva(DADES_PROVA);
