// TODO: crea aquí la classe Contacte i els tipus relacionats
