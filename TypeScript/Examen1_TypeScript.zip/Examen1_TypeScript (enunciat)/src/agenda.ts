// TODO: crea aquí la classe estàtica Agenda
